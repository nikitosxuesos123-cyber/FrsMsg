package com.FrosvanDevelop.Frsgram.domain.model

enum class MessageType { TEXT, IMAGE }

enum class MessageStatus { SENDING, SENT, DELIVERED, READ, FAILED }

data class Message(
    val messageId: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val type: String = MessageType.TEXT.name,
    val text: String = "",
    val mediaUrl: String = "",
    val timestamp: Long = 0L,
    val editedAt: Long = 0L,
    val replyTo: String = "",
    val deleted: Boolean = false,
    val status: MessageStatus = MessageStatus.SENT,
    val deliveredAt: Long = 0L,
    val readAt: Long = 0L,
)
