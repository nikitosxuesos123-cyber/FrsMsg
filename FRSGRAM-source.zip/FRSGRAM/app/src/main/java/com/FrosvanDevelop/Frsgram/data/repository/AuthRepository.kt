package com.FrosvanDevelop.Frsgram.data.repository

import com.FrosvanDevelop.Frsgram.domain.model.UserProfile

interface AuthRepository {
    val currentUid: String?
    suspend fun getCurrentProfile(): UserProfile?
    suspend fun createAnonymousIdentity(): UserProfile
    suspend fun syncMessagingToken()
    fun startPresence()
}
