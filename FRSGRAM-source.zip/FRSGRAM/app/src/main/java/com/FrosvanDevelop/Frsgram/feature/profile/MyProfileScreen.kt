package com.FrosvanDevelop.Frsgram.feature.profile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.FrosvanDevelop.Frsgram.core.design.*

@Composable
fun MyProfileScreen(onBack: () -> Unit, viewModel: MyProfileViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().background(FrsColors.Background).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FrsSecondaryButton("‹", onBack, Modifier.size(44.dp))
            Spacer(Modifier.width(14.dp))
            Text("Profile", color = FrsColors.Text, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(34.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FrsAvatar(state.username, Modifier.size(72.dp))
            Spacer(Modifier.width(18.dp))
            Column {
                Text(state.profile?.username ?: "Anonymous", color = FrsColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(5.dp))
                Text(state.profile?.publicId.orEmpty(), color = FrsColors.TextSecondary, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(28.dp))
        if (state.editing) {
            Text("Nickname", color = FrsColors.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(7.dp))
            FrsTextField(state.username, viewModel::setUsername, "Nickname", Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Text("Bio", color = FrsColors.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(7.dp))
            FrsTextField(state.bio, viewModel::setBio, "Optional bio", Modifier.fillMaxWidth(), singleLine = false)
            Spacer(Modifier.height(16.dp))
            Row {
                FrsSecondaryButton("Cancel", viewModel::cancel, Modifier.weight(1f))
                Spacer(Modifier.width(10.dp))
                FrsButton(if (state.saving) "Saving…" else "Save", viewModel::save, Modifier.weight(1f), enabled = !state.saving)
            }
        } else {
            Text(state.profile?.bio?.ifBlank { "No bio" } ?: "", color = FrsColors.TextSecondary, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            FrsSecondaryButton("Copy ID", {
                val id = state.profile?.publicId.orEmpty()
                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("FRSGRAM ID", id))
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            FrsButton("Edit profile", viewModel::edit, Modifier.fillMaxWidth())
        }
        if (state.error.isNotBlank()) {
            Spacer(Modifier.height(14.dp)); Text(state.error, color = FrsColors.TextSecondary, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("Your public ID can be shared. Firebase UID stays internal.", color = FrsColors.Muted, fontSize = 11.sp)
    }
}
