package com.FrosvanDevelop.Frsgram.core.design

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object FrsColors {
    val Background = Color(0xFF0B0B0C)
    val Background2 = Color(0xFF101012)
    val Surface = Color(0xFF151517)
    val Elevated = Color(0xFF1B1B1E)
    val Input = Color(0xFF18181B)
    val Divider = Color(0xFF252529)
    val Text = Color(0xFFF2F2F3)
    val TextSecondary = Color(0xFFA1A1A6)
    val Muted = Color(0xFF68686E)
    val Accent = Color(0xFFCACACE)
}

private val FrsScheme = darkColorScheme(
    primary = FrsColors.Accent,
    onPrimary = FrsColors.Background,
    background = FrsColors.Background,
    onBackground = FrsColors.Text,
    surface = FrsColors.Surface,
    onSurface = FrsColors.Text,
    surfaceVariant = FrsColors.Elevated,
    onSurfaceVariant = FrsColors.TextSecondary,
    outline = FrsColors.Divider,
    error = Color(0xFFC9A1A1),
)

@Composable
fun FrsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = FrsScheme,
        typography = MaterialTheme.typography,
        content = content,
    )
}
