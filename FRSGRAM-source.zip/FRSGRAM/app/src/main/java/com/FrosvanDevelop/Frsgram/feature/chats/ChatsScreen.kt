package com.FrosvanDevelop.Frsgram.feature.chats

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.FrosvanDevelop.Frsgram.core.design.*
import com.FrosvanDevelop.Frsgram.domain.model.ChatSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatsScreen(
    onOpenChat: (String) -> Unit,
    onSearch: () -> Unit,
    onProfile: () -> Unit,
    onSettings: () -> Unit,
    viewModel: ChatsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    Box(Modifier.fillMaxSize().background(FrsColors.Background)) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 18.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FrsAvatar("F", Modifier.size(38.dp).clickableNoRipple(onProfile))
                Spacer(Modifier.width(12.dp))
                Text("FRSGRAM", color = FrsColors.Text, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)
                Spacer(Modifier.weight(1f))
                HeaderIcon(Icons.Rounded.Search, onSearch)
                HeaderIcon(Icons.Rounded.Settings, onSettings)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(FrsColors.Divider))

            when {
                state.loading -> ChatsSkeleton()
                state.chats.isEmpty() -> EmptyChats(onSearch)
                else -> LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
                    items(state.chats, key = { it.chatId }) { chat ->
                        ChatRow(chat = chat, onClick = { onOpenChat(chat.chatId) })
                    }
                }
            }
        }

        Box(
            Modifier.align(Alignment.BottomEnd).padding(22.dp).size(52.dp)
                .clip(CircleShape).background(FrsColors.Accent).clickableNoRipple(onSearch),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Add, null, tint = FrsColors.Background, modifier = Modifier.size(24.dp))
        }
        AnimatedVisibility(state.error.isNotBlank(), Modifier.align(Alignment.BottomCenter)) {
            Text(state.error, color = FrsColors.TextSecondary, modifier = Modifier.padding(20.dp))
        }
    }
}

@Composable
private fun HeaderIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(42.dp).clip(CircleShape).clickableNoRipple(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = FrsColors.TextSecondary, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun ChatRow(chat: ChatSummary, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickableNoRipple(onClick).padding(horizontal = 20.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FrsAvatar(chat.peerUsername, Modifier.size(52.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(chat.peerUsername, color = FrsColors.Text, fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(formatChatTime(chat.lastMessageAt), color = FrsColors.Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(chat.lastMessage.ifBlank { "Conversation started" }, color = FrsColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (chat.unreadCount > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.defaultMinSize(minWidth = 20.dp).height(20.dp).background(FrsColors.Accent, CircleShape).padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
                        Text(chat.unreadCount.coerceAtMost(99).toString(), color = FrsColors.Background, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChats(onSearch: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp).background(FrsColors.Surface, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text("F", color = FrsColors.TextSecondary, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(22.dp))
        Text("No conversations yet", color = FrsColors.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Text("Share your ID or start a new chat.", color = FrsColors.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        FrsSecondaryButton("New chat", onSearch, Modifier.width(150.dp))
    }
}

@Composable
private fun ChatsSkeleton() {
    Column(Modifier.padding(top = 8.dp)) {
        repeat(5) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).background(FrsColors.Surface, CircleShape))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth(.45f).height(13.dp).background(FrsColors.Surface, RoundedCornerShape(6.dp)))
                    Spacer(Modifier.height(9.dp))
                    Box(Modifier.fillMaxWidth(.7f).height(10.dp).background(FrsColors.Surface, RoundedCornerShape(5.dp)))
                }
            }
        }
    }
}

private fun formatChatTime(value: Long): String = if (value <= 0) "" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(value))

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = clickable(
    interactionSource = MutableInteractionSource(), indication = null, onClick = onClick,
)
