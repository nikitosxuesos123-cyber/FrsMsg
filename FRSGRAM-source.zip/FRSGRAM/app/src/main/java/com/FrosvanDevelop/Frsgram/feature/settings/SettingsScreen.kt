package com.FrosvanDevelop.Frsgram.feature.settings

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.FrosvanDevelop.Frsgram.core.design.*
import com.FrosvanDevelop.Frsgram.core.util.SecurityPrefs

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("frsgram_settings", Context.MODE_PRIVATE) }
    var blockScreenshots by remember { mutableStateOf(SecurityPrefs.blockScreenshots(context)) }
    var animations by remember { mutableStateOf(prefs.getBoolean("animations", true)) }
    var privateNotifications by remember { mutableStateOf(prefs.getBoolean("private_notifications", true)) }

    Column(Modifier.fillMaxSize().background(FrsColors.Background)) {
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            FrsSecondaryButton("‹", onBack, Modifier.size(44.dp))
            Spacer(Modifier.width(14.dp))
            Text("Settings", color = FrsColors.Text, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        }
        Section("PRIVACY") {
            SettingToggle("Block screenshots", "Uses Android secure-window protection", blockScreenshots) {
                blockScreenshots = it
                SecurityPrefs.setBlockScreenshots(context, it)
            }
            SettingToggle("Private notifications", "Notification text stays hidden", privateNotifications) {
                privateNotifications = it; prefs.edit().putBoolean("private_notifications", it).apply()
            }
        }
        Section("APPEARANCE") {
            SettingToggle("Animations", "Short, subtle interface motion", animations) {
                animations = it; prefs.edit().putBoolean("animations", it).apply()
            }
            SettingInfo("Theme", "Graphite / OLED dark")
        }
        Section("SECURITY") {
            SettingInfo("Account", "Firebase anonymous identity")
            SettingInfo("Transport", "Firebase TLS + Security Rules")
        }
        Spacer(Modifier.weight(1f))
        Text("FRSGRAM 0.1.0", color = FrsColors.Muted, fontSize = 11.sp, modifier = Modifier.padding(20.dp))
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, color = FrsColors.Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp))
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).background(FrsColors.Surface, RoundedCornerShape(16.dp)), content = content)
}

@Composable
private fun SettingToggle(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickableNoRipple { onChecked(!checked) }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = FrsColors.Text, fontSize = 14.sp)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = FrsColors.Muted, fontSize = 11.sp)
        }
        GrayToggle(checked)
    }
}

@Composable
private fun SettingInfo(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = FrsColors.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = FrsColors.Muted, fontSize = 11.sp)
    }
}

@Composable
private fun GrayToggle(checked: Boolean) {
    val bg by animateColorAsState(if (checked) FrsColors.Accent else FrsColors.Divider, label = "toggle")
    Box(Modifier.width(42.dp).height(24.dp).background(bg, CircleShape).padding(3.dp)) {
        Box(Modifier.size(18.dp).align(if (checked) Alignment.CenterEnd else Alignment.CenterStart).background(if (checked) FrsColors.Background else FrsColors.Muted, CircleShape))
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = clickable(
    interactionSource = MutableInteractionSource(), indication = null, onClick = onClick,
)
