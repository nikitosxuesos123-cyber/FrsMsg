package com.FrosvanDevelop.Frsgram.feature.chat

import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.AuthRepository
import com.FrosvanDevelop.Frsgram.data.repository.ChatRepository
import com.FrosvanDevelop.Frsgram.data.repository.MediaRepository
import com.FrosvanDevelop.Frsgram.data.repository.UserRepository
import com.FrosvanDevelop.Frsgram.domain.model.Message
import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

data class ChatUiState(
    val chatId: String = "",
    val myUid: String = "",
    val peer: UserProfile? = null,
    val messages: List<Message> = emptyList(),
    val input: String = "",
    val loading: Boolean = true,
    val sendingMedia: Boolean = false,
    val replyTo: Message? = null,
    val error: String = "",
    val imageUrls: Map<String, String> = emptyMap(),
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val chats: ChatRepository,
    private val users: UserRepository,
    private val media: MediaRepository,
    auth: AuthRepository,
) : ViewModel() {
    private val chatId: String = savedStateHandle["chatId"] ?: ""
    private val _state = MutableStateFlow(ChatUiState(chatId = chatId, myUid = auth.currentUid.orEmpty()))
    val state: StateFlow<ChatUiState> = _state.asStateFlow()
    private var messageJob: Job? = null

    init {
        if (chatId.isBlank()) {
            _state.value = _state.value.copy(loading = false, error = "Invalid conversation")
        } else {
            viewModelScope.launch {
                runCatching { chats.getPeerUid(chatId) }
                    .onSuccess { peerUid ->
                        _state.value = _state.value.copy(peer = users.getProfile(peerUid))
                        subscribeMessages()
                    }
                    .onFailure { _state.value = _state.value.copy(loading = false, error = it.message ?: "Couldn't open conversation") }
            }
        }
    }

    private fun subscribeMessages() {
        messageJob?.cancel()
        messageJob = viewModelScope.launch {
            chats.observeMessages(chatId)
                .catch { _state.value = _state.value.copy(loading = false, error = it.message ?: "Connection error") }
                .collect { list ->
                    _state.value = _state.value.copy(messages = list, loading = false)
                    val unresolved = list.filter { it.type == "IMAGE" && it.mediaUrl.isNotBlank() && !_state.value.imageUrls.containsKey(it.messageId) }
                    if (unresolved.isNotEmpty()) {
                        val resolved = _state.value.imageUrls.toMutableMap()
                        unresolved.forEach { message ->
                            runCatching { media.resolveDownloadUrl(message.mediaUrl) }.getOrNull()?.let { resolved[message.messageId] = it }
                        }
                        _state.value = _state.value.copy(imageUrls = resolved)
                    }
                    if (list.any { it.senderId != _state.value.myUid }) runCatching { chats.markRead(chatId) }
                }
        }
    }

    fun setInput(value: String) { _state.value = _state.value.copy(input = value.take(4000)) }
    fun setReply(message: Message?) { _state.value = _state.value.copy(replyTo = message) }
    fun clearError() { _state.value = _state.value.copy(error = "") }

    fun send() {
        val text = state.value.input.trim()
        if (text.isBlank()) return
        val reply = state.value.replyTo?.messageId.orEmpty()
        _state.value = _state.value.copy(input = "", replyTo = null, error = "")
        viewModelScope.launch {
            runCatching { chats.sendText(chatId, text, reply) }
                .onFailure { _state.value = _state.value.copy(error = "Couldn't send message. Tap to retry.") }
        }
    }

    fun sendImage(uri: Uri) {
        val peerUid = state.value.peer?.uid ?: return
        val reply = state.value.replyTo?.messageId.orEmpty()
        viewModelScope.launch {
            _state.value = _state.value.copy(sendingMedia = true, error = "")
            runCatching {
                val url = media.uploadChatImage(chatId, peerUid, uri)
                chats.sendImage(chatId, url, reply)
            }.onSuccess {
                _state.value = _state.value.copy(sendingMedia = false, replyTo = null)
            }.onFailure {
                _state.value = _state.value.copy(sendingMedia = false, error = it.message ?: "Image upload failed")
            }
        }
    }

    fun edit(message: Message, newText: String) {
        viewModelScope.launch {
            runCatching { chats.editMessage(chatId, message.messageId, newText) }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Couldn't edit message") }
        }
    }

    fun delete(message: Message) {
        viewModelScope.launch {
            runCatching { chats.deleteMessage(chatId, message.messageId) }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Couldn't delete message") }
        }
    }

    fun blockPeer(onDone: () -> Unit) {
        val uid = state.value.peer?.uid ?: return
        viewModelScope.launch {
            runCatching { users.blockUser(uid) }
                .onSuccess { onDone() }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Couldn't block user") }
        }
    }

    fun reportPeer(reason: String) {
        val uid = state.value.peer?.uid ?: return
        viewModelScope.launch {
            runCatching { users.reportUser(uid, reason) }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Couldn't send report") }
        }
    }
}
