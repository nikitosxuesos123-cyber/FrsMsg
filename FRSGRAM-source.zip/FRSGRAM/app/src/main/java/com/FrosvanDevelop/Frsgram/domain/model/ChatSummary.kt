package com.FrosvanDevelop.Frsgram.domain.model

data class ChatSummary(
    val chatId: String = "",
    val peerUid: String = "",
    val peerPublicId: String = "",
    val peerUsername: String = "",
    val peerAvatarUrl: String = "",
    val lastMessage: String = "",
    val lastMessageAt: Long = 0L,
    val unreadCount: Int = 0,
)
