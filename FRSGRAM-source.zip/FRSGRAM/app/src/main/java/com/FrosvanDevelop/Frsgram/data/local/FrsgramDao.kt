package com.FrosvanDevelop.Frsgram.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface FrsgramDao {
    @Query("SELECT * FROM chat_cache ORDER BY lastMessageAt DESC")
    fun observeChats(): Flow<List<ChatEntity>>

    @Upsert
    suspend fun upsertChats(chats: List<ChatEntity>)

    @Query("DELETE FROM chat_cache WHERE chatId NOT IN (:chatIds)")
    suspend fun deleteChatsNotIn(chatIds: List<String>)

    @Query("DELETE FROM chat_cache")
    suspend fun clearChats()

    @Query("SELECT * FROM message_cache WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun observeMessages(chatId: String): Flow<List<MessageEntity>>

    @Upsert
    suspend fun upsertMessages(messages: List<MessageEntity>)

    @Upsert
    suspend fun upsertMessage(message: MessageEntity)

    @Query("DELETE FROM message_cache WHERE chatId = :chatId")
    suspend fun clearMessages(chatId: String)
}
