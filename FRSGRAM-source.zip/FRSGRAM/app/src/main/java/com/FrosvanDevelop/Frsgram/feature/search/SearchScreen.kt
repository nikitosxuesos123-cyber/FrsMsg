package com.FrosvanDevelop.Frsgram.feature.search

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.FrosvanDevelop.Frsgram.core.design.*

@Composable
fun SearchScreen(
    onBack: () -> Unit,
    onOpenChat: (String) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(state.openChatId) { if (state.openChatId.isNotBlank()) onOpenChat(state.openChatId) }

    Column(Modifier.fillMaxSize().background(FrsColors.Background).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            FrsSecondaryButton("‹", onBack, Modifier.size(44.dp))
            Spacer(Modifier.width(14.dp))
            Text("New chat", color = FrsColors.Text, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("Find by FRSGRAM ID", color = FrsColors.TextSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FrsTextField(state.query, viewModel::setQuery, "@7K2M-9QPX", Modifier.weight(1f))
            Spacer(Modifier.width(10.dp))
            FrsButton("Find", viewModel::search, Modifier.width(82.dp), enabled = !state.loading)
        }
        Spacer(Modifier.height(24.dp))
        state.result?.let { profile ->
            Row(Modifier.fillMaxWidth().background(FrsColors.Surface, androidx.compose.foundation.shape.RoundedCornerShape(18.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                FrsAvatar(profile.username, Modifier.size(58.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(profile.username, color = FrsColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(3.dp))
                    Text(profile.publicId, color = FrsColors.TextSecondary, fontSize = 12.sp)
                    if (profile.bio.isNotBlank()) {
                        Spacer(Modifier.height(7.dp))
                        Text(profile.bio, color = FrsColors.Muted, fontSize = 12.sp, maxLines = 2)
                    }
                }
                FrsSecondaryButton("Message", viewModel::message, Modifier.width(100.dp))
            }
        }
        if (state.loading) {
            Text("Searching…", color = FrsColors.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
        }
        if (state.error.isNotBlank()) {
            Text(state.error, color = FrsColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
        }
        Spacer(Modifier.weight(1f))
        Text("Your Firebase UID is never used as a public identifier.", color = FrsColors.Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 24.dp))
    }
}
