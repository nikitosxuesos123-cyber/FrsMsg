package com.FrosvanDevelop.Frsgram.data.repository

import com.FrosvanDevelop.Frsgram.core.util.toUserProfile
import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseUserRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val database: FirebaseDatabase,
) : UserRepository {
    override suspend fun getProfile(uid: String): UserProfile? =
        database.reference.child("publicProfiles").child(uid).get().await().toUserProfile()

    override suspend fun findByPublicId(publicId: String): UserProfile? {
        val key = publicId.trim().removePrefix("@").replace("-", "").uppercase()
        if (key.length != 8) return null
        val uid = database.reference.child("publicIds").child(key).get().await().getValue(String::class.java)
            ?: return null
        return getProfile(uid)
    }

    override suspend fun updateMyProfile(username: String, bio: String, avatarUrl: String) {
        val uid = auth.currentUser?.uid ?: error("Not authenticated")
        val safeUsername = username.trim().take(32).ifBlank { "Anonymous" }
        val safeBio = bio.trim().take(140)
        database.reference.child("publicProfiles").child(uid).updateChildren(
            mapOf(
                "username" to safeUsername,
                "bio" to safeBio,
                "avatarUrl" to avatarUrl.take(1000),
            )
        ).await()
    }

    override suspend fun blockUser(uid: String) {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        require(uid != me)
        database.reference.child("blockedUsers").child(me).child(uid).setValue(true).await()
    }

    override suspend fun unblockUser(uid: String) {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        database.reference.child("blockedUsers").child(me).child(uid).removeValue().await()
    }

    override suspend fun reportUser(uid: String, reason: String, messageIds: List<String>) {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        val reportId = database.reference.child("reports").push().key ?: error("Could not create report ID")
        val report = mapOf(
            "reporterUid" to me,
            "reportedUid" to uid,
            "reason" to reason.take(64),
            "messageIds" to messageIds.take(20),
            "createdAt" to ServerValue.TIMESTAMP,
        )
        database.reference.child("reports").child(reportId).setValue(report).await()
    }
}
