package com.FrosvanDevelop.Frsgram.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.FrosvanDevelop.Frsgram.domain.model.ChatSummary
import com.FrosvanDevelop.Frsgram.domain.model.Message
import com.FrosvanDevelop.Frsgram.domain.model.MessageStatus

@Entity(tableName = "chat_cache")
data class ChatEntity(
    @PrimaryKey val chatId: String,
    val peerUid: String,
    val peerPublicId: String,
    val peerUsername: String,
    val peerAvatarUrl: String,
    val lastMessage: String,
    val lastMessageAt: Long,
    val unreadCount: Int,
)

@Entity(
    tableName = "message_cache",
    indices = [Index(value = ["chatId", "timestamp"])]
)
data class MessageEntity(
    @PrimaryKey val messageId: String,
    val chatId: String,
    val senderId: String,
    val type: String,
    val text: String,
    val mediaUrl: String,
    val timestamp: Long,
    val editedAt: Long,
    val replyTo: String,
    val deleted: Boolean,
    val status: String,
    val deliveredAt: Long,
    val readAt: Long,
)

fun ChatEntity.toDomain() = ChatSummary(
    chatId = chatId,
    peerUid = peerUid,
    peerPublicId = peerPublicId,
    peerUsername = peerUsername,
    peerAvatarUrl = peerAvatarUrl,
    lastMessage = lastMessage,
    lastMessageAt = lastMessageAt,
    unreadCount = unreadCount,
)

fun ChatSummary.toEntity() = ChatEntity(
    chatId = chatId,
    peerUid = peerUid,
    peerPublicId = peerPublicId,
    peerUsername = peerUsername,
    peerAvatarUrl = peerAvatarUrl,
    lastMessage = lastMessage,
    lastMessageAt = lastMessageAt,
    unreadCount = unreadCount,
)

fun MessageEntity.toDomain() = Message(
    messageId = messageId,
    chatId = chatId,
    senderId = senderId,
    type = type,
    text = text,
    mediaUrl = mediaUrl,
    timestamp = timestamp,
    editedAt = editedAt,
    replyTo = replyTo,
    deleted = deleted,
    status = runCatching { MessageStatus.valueOf(status) }.getOrDefault(MessageStatus.SENT),
    deliveredAt = deliveredAt,
    readAt = readAt,
)

fun Message.toEntity() = MessageEntity(
    messageId = messageId,
    chatId = chatId,
    senderId = senderId,
    type = type,
    text = text,
    mediaUrl = mediaUrl,
    timestamp = timestamp,
    editedAt = editedAt,
    replyTo = replyTo,
    deleted = deleted,
    status = status.name,
    deliveredAt = deliveredAt,
    readAt = readAt,
)
