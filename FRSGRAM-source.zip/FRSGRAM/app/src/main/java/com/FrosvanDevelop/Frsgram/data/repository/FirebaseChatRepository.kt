package com.FrosvanDevelop.Frsgram.data.repository

import androidx.room.withTransaction
import com.FrosvanDevelop.Frsgram.data.local.FrsgramDatabase
import com.FrosvanDevelop.Frsgram.data.local.toDomain
import com.FrosvanDevelop.Frsgram.data.local.toEntity
import com.FrosvanDevelop.Frsgram.domain.model.ChatSummary
import com.FrosvanDevelop.Frsgram.domain.model.Message
import com.FrosvanDevelop.Frsgram.domain.model.MessageStatus
import com.FrosvanDevelop.Frsgram.domain.model.MessageType
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseChatRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val database: FirebaseDatabase,
    private val localDb: FrsgramDatabase,
) : ChatRepository {
    private val dao get() = localDb.dao()
    private val root get() = database.reference

    override fun observeChats(): Flow<List<ChatSummary>> = channelFlow {
        val uid = auth.currentUser?.uid ?: run {
            send(emptyList())
            return@channelFlow
        }
        val localJob = launch {
            dao.observeChats().collectLatest { cached -> send(cached.map { it.toDomain() }) }
        }
        val ref = root.child("userChats").child(uid)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                launch {
                    val remote = snapshot.children.mapNotNull { child ->
                        val chatId = child.key ?: return@mapNotNull null
                        val peerUid = child.child("peerUid").getValue(String::class.java).orEmpty()
                        if (peerUid.isBlank()) return@mapNotNull null
                        val profile = root.child("publicProfiles").child(peerUid).get().await()
                        ChatSummary(
                            chatId = chatId,
                            peerUid = peerUid,
                            peerPublicId = profile.child("publicId").getValue(String::class.java).orEmpty(),
                            peerUsername = profile.child("username").getValue(String::class.java).orEmpty().ifBlank { "Anonymous" },
                            peerAvatarUrl = profile.child("avatarUrl").getValue(String::class.java).orEmpty(),
                            lastMessage = child.child("lastMessage").getValue(String::class.java).orEmpty(),
                            lastMessageAt = child.child("lastMessageAt").getValue(Long::class.java) ?: 0L,
                            unreadCount = (child.child("unreadCount").getValue(Long::class.java) ?: 0L).toInt(),
                        )
                    }.sortedByDescending { it.lastMessageAt }
                    localDb.withTransaction {
                        if (remote.isEmpty()) dao.clearChats() else {
                            dao.upsertChats(remote.map { it.toEntity() })
                            dao.deleteChatsNotIn(remote.map { it.chatId })
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) = Unit
        }
        ref.addValueEventListener(listener)
        awaitClose {
            ref.removeEventListener(listener)
            localJob.cancel()
        }
    }

    override suspend fun openOrCreateChat(peerUid: String): String {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        require(peerUid.isNotBlank() && peerUid != me)
        val blockedByMe = root.child("blockedUsers").child(me).child(peerUid).get().await().exists()
        val blockedByPeer = root.child("blockedUsers").child(peerUid).child(me).get().await().exists()
        require(!blockedByMe && !blockedByPeer) { "This conversation is blocked" }

        val sorted = listOf(me, peerUid).sorted()
        val chatId = "${sorted[0]}_${sorted[1]}"
        val existing = root.child("chats").child(chatId).get().await()
        if (!existing.exists()) {
            root.child("chats").child(chatId).setValue(
                mapOf(
                    "createdAt" to ServerValue.TIMESTAMP,
                    "updatedAt" to ServerValue.TIMESTAMP,
                    "participantA" to sorted[0],
                    "participantB" to sorted[1],
                    "participants" to mapOf(me to true, peerUid to true),
                )
            ).await()
            val updates = hashMapOf<String, Any?>(
                "userChats/$me/$chatId" to mapOf(
                    "peerUid" to peerUid,
                    "lastMessage" to "Conversation started",
                    "lastMessageAt" to ServerValue.TIMESTAMP,
                    "unreadCount" to 0,
                    "muted" to false,
                    "archived" to false,
                ),
                "userChats/$peerUid/$chatId" to mapOf(
                    "peerUid" to me,
                    "lastMessage" to "Conversation started",
                    "lastMessageAt" to ServerValue.TIMESTAMP,
                    "unreadCount" to 0,
                    "muted" to false,
                    "archived" to false,
                ),
            )
            root.updateChildren(updates).await()
        }
        return chatId
    }

    override suspend fun getPeerUid(chatId: String): String {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        val snapshot = root.child("chats").child(chatId).child("participants").get().await()
        return snapshot.children.mapNotNull { it.key }.firstOrNull { it != me }
            ?: error("Conversation peer not found")
    }

    override fun observeMessages(chatId: String): Flow<List<Message>> = channelFlow {
        val me = auth.currentUser?.uid ?: run {
            send(emptyList())
            return@channelFlow
        }
        val localJob = launch {
            dao.observeMessages(chatId).collectLatest { cached ->
                send(cached.map { it.toDomain() })
            }
        }

        val peerUid = runCatching { getPeerUid(chatId) }.getOrElse {
            localJob.cancel()
            close(it)
            return@channelFlow
        }
        val messagesRef = root.child("messages").child(chatId)
        val query = messagesRef.orderByChild("timestamp").limitToLast(100)
        val peerReceiptRef = root.child("messageReceipts").child(chatId).child(peerUid)
        var lastSnapshots: List<DataSnapshot> = emptyList()
        var peerDeliveredAt = 0L
        var peerReadAt = 0L

        fun persistRemote() {
            val mapped = lastSnapshots.mapNotNull { snap ->
                val id = snap.key ?: return@mapNotNull null
                val sender = snap.child("senderId").getValue(String::class.java).orEmpty()
                val timestamp = snap.child("timestamp").getValue(Long::class.java) ?: 0L
                val mine = sender == me
                val status = when {
                    !mine -> MessageStatus.SENT
                    peerReadAt >= timestamp && timestamp > 0 -> MessageStatus.READ
                    peerDeliveredAt >= timestamp && timestamp > 0 -> MessageStatus.DELIVERED
                    else -> MessageStatus.SENT
                }
                Message(
                    messageId = id,
                    chatId = chatId,
                    senderId = sender,
                    type = snap.child("type").getValue(String::class.java) ?: MessageType.TEXT.name,
                    text = snap.child("text").getValue(String::class.java).orEmpty(),
                    mediaUrl = snap.child("mediaUrl").getValue(String::class.java).orEmpty(),
                    timestamp = timestamp,
                    editedAt = snap.child("editedAt").getValue(Long::class.java) ?: 0L,
                    replyTo = snap.child("replyTo").getValue(String::class.java).orEmpty(),
                    deleted = snap.child("deleted").getValue(Boolean::class.java) ?: false,
                    status = status,
                    deliveredAt = if (mine) peerDeliveredAt else 0L,
                    readAt = if (mine) peerReadAt else 0L,
                )
            }.sortedBy { it.timestamp }
            launch {
                if (mapped.isNotEmpty()) dao.upsertMessages(mapped.map { it.toEntity() })
            }
            if (mapped.any { it.senderId != me }) {
                root.child("messageReceipts").child(chatId).child(me).child("deliveredAt")
                    .setValue(ServerValue.TIMESTAMP)
            }
        }

        val messageListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lastSnapshots = snapshot.children.toList()
                persistRemote()
            }
            override fun onCancelled(error: DatabaseError) = Unit
        }
        val receiptListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                peerDeliveredAt = snapshot.child("deliveredAt").getValue(Long::class.java) ?: 0L
                peerReadAt = snapshot.child("readAt").getValue(Long::class.java) ?: 0L
                persistRemote()
            }
            override fun onCancelled(error: DatabaseError) = Unit
        }
        query.addValueEventListener(messageListener)
        peerReceiptRef.addValueEventListener(receiptListener)

        awaitClose {
            query.removeEventListener(messageListener)
            peerReceiptRef.removeEventListener(receiptListener)
            localJob.cancel()
        }
    }

    override suspend fun loadOlder(chatId: String, beforeTimestamp: Long, limit: Int): List<Message> {
        val snap = root.child("messages").child(chatId)
            .orderByChild("timestamp")
            .endAt((beforeTimestamp - 1).toDouble())
            .limitToLast(limit)
            .get().await()
        return snap.children.mapNotNull { it.toMessage(chatId) }.sortedBy { it.timestamp }
    }

    override suspend fun sendText(chatId: String, text: String, replyTo: String) {
        val clean = text.trim().take(4000)
        require(clean.isNotEmpty())
        sendMessage(chatId, MessageType.TEXT, clean, "", replyTo)
    }

    override suspend fun sendImage(chatId: String, mediaUrl: String, replyTo: String) {
        require(mediaUrl.startsWith("chatMedia/"))
        sendMessage(chatId, MessageType.IMAGE, "Image", mediaUrl, replyTo)
    }

    private suspend fun sendMessage(
        chatId: String,
        type: MessageType,
        text: String,
        mediaUrl: String,
        replyTo: String,
    ) {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        val peer = getPeerUid(chatId)
        val messageId = root.child("messages").child(chatId).push().key ?: error("Message ID unavailable")
        val localTimestamp = System.currentTimeMillis()
        dao.upsertMessage(
            Message(
                messageId = messageId,
                chatId = chatId,
                senderId = me,
                type = type.name,
                text = text,
                mediaUrl = mediaUrl,
                timestamp = localTimestamp,
                replyTo = replyTo,
                status = MessageStatus.SENDING,
            ).toEntity()
        )

        val payload = mapOf(
            "senderId" to me,
            "type" to type.name,
            "text" to text,
            "mediaUrl" to mediaUrl,
            "timestamp" to ServerValue.TIMESTAMP,
            "editedAt" to 0,
            "replyTo" to replyTo.take(100),
            "deleted" to false,
        )
        val preview = if (type == MessageType.IMAGE) "Photo" else text.take(120)
        val updates = hashMapOf<String, Any?>(
            "messages/$chatId/$messageId" to payload,
            "chats/$chatId/updatedAt" to ServerValue.TIMESTAMP,
            "userChats/$me/$chatId/lastMessage" to preview,
            "userChats/$me/$chatId/lastMessageAt" to ServerValue.TIMESTAMP,
            "userChats/$me/$chatId/unreadCount" to 0,
            "userChats/$peer/$chatId/lastMessage" to preview,
            "userChats/$peer/$chatId/lastMessageAt" to ServerValue.TIMESTAMP,
            "userChats/$peer/$chatId/unreadCount" to ServerValue.increment(1),
        )
        try {
            root.updateChildren(updates).await()
            dao.upsertMessage(
                Message(
                    messageId = messageId,
                    chatId = chatId,
                    senderId = me,
                    type = type.name,
                    text = text,
                    mediaUrl = mediaUrl,
                    timestamp = localTimestamp,
                    replyTo = replyTo,
                    status = MessageStatus.SENT,
                ).toEntity()
            )
        } catch (t: Throwable) {
            dao.upsertMessage(
                Message(
                    messageId = messageId,
                    chatId = chatId,
                    senderId = me,
                    type = type.name,
                    text = text,
                    mediaUrl = mediaUrl,
                    timestamp = localTimestamp,
                    replyTo = replyTo,
                    status = MessageStatus.FAILED,
                ).toEntity()
            )
            throw t
        }
    }

    override suspend fun editMessage(chatId: String, messageId: String, newText: String) {
        val clean = newText.trim().take(4000)
        require(clean.isNotEmpty())
        root.child("messages").child(chatId).child(messageId).updateChildren(
            mapOf("text" to clean, "editedAt" to ServerValue.TIMESTAMP)
        ).await()
    }

    override suspend fun deleteMessage(chatId: String, messageId: String) {
        root.child("messages").child(chatId).child(messageId).updateChildren(
            mapOf(
                "text" to "",
                "mediaUrl" to "",
                "deleted" to true,
                "editedAt" to ServerValue.TIMESTAMP,
            )
        ).await()
    }

    override suspend fun markRead(chatId: String) {
        val me = auth.currentUser?.uid ?: return
        val updates = hashMapOf<String, Any?>(
            "messageReceipts/$chatId/$me/readAt" to ServerValue.TIMESTAMP,
            "messageReceipts/$chatId/$me/deliveredAt" to ServerValue.TIMESTAMP,
            "userChats/$me/$chatId/unreadCount" to 0,
        )
        root.updateChildren(updates).await()
    }

    override suspend fun muteChat(chatId: String, muted: Boolean) {
        val me = auth.currentUser?.uid ?: return
        root.child("userChats").child(me).child(chatId).child("muted").setValue(muted).await()
    }

    override suspend fun archiveChat(chatId: String, archived: Boolean) {
        val me = auth.currentUser?.uid ?: return
        root.child("userChats").child(me).child(chatId).child("archived").setValue(archived).await()
    }

    private fun DataSnapshot.toMessage(chatId: String): Message? {
        val id = key ?: return null
        return Message(
            messageId = id,
            chatId = chatId,
            senderId = child("senderId").getValue(String::class.java).orEmpty(),
            type = child("type").getValue(String::class.java) ?: MessageType.TEXT.name,
            text = child("text").getValue(String::class.java).orEmpty(),
            mediaUrl = child("mediaUrl").getValue(String::class.java).orEmpty(),
            timestamp = child("timestamp").getValue(Long::class.java) ?: 0L,
            editedAt = child("editedAt").getValue(Long::class.java) ?: 0L,
            replyTo = child("replyTo").getValue(String::class.java).orEmpty(),
            deleted = child("deleted").getValue(Boolean::class.java) ?: false,
        )
    }
}
