package com.FrosvanDevelop.Frsgram.core.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager

object SecurityPrefs {
    private const val FILE = "frsgram_security"
    private const val KEY_BLOCK_SCREENSHOTS = "block_screenshots"

    fun blockScreenshots(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_BLOCK_SCREENSHOTS, false)

    fun setBlockScreenshots(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_BLOCK_SCREENSHOTS, enabled).apply()
        context.findActivity()?.applyScreenshotPolicy(enabled)
    }

    fun Activity.applyScreenshotPolicy(enabled: Boolean = blockScreenshots(this)) {
        if (enabled) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private tailrec fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }
}
