package com.FrosvanDevelop.Frsgram.domain.model

data class UserProfile(
    val uid: String = "",
    val publicId: String = "",
    val username: String = "",
    val bio: String = "",
    val avatarUrl: String = "",
    val createdAt: Long = 0L,
    val online: Boolean = false,
)
