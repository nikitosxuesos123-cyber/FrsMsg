package com.FrosvanDevelop.Frsgram.data.repository

import com.FrosvanDevelop.Frsgram.core.util.toUserProfile
import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

@Singleton
class FirebaseAuthRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val database: FirebaseDatabase,
    private val messaging: FirebaseMessaging,
) : AuthRepository {

    private val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private val random = SecureRandom()
    private var presenceListener: ValueEventListener? = null

    override val currentUid: String?
        get() = auth.currentUser?.uid

    override suspend fun getCurrentProfile(): UserProfile? {
        val uid = currentUid ?: return null
        return database.reference.child("publicProfiles").child(uid).get().await().toUserProfile()
    }

    override suspend fun createAnonymousIdentity(): UserProfile {
        val user = auth.currentUser ?: auth.signInAnonymously().await().user
            ?: error("Firebase anonymous authentication returned no user")
        val existing = database.reference.child("publicProfiles").child(user.uid).get().await().toUserProfile()
        if (existing != null && existing.publicId.isNotBlank()) {
            syncMessagingToken()
            startPresence()
            return existing
        }

        repeat(30) {
            val key = randomPublicIdKey()
            if (claimPublicId(key, user.uid)) {
                val displayId = "@${key.take(4)}-${key.drop(4)}"
                val suffix = random.nextInt(9000) + 1000
                val nowMap = ServerValue.TIMESTAMP
                val publicProfile = mapOf(
                    "publicId" to displayId,
                    "username" to "Anonymous $suffix",
                    "bio" to "",
                    "avatarUrl" to "",
                    "createdAt" to nowMap,
                    "online" to true,
                )
                val privateProfile = mapOf(
                    "createdAt" to nowMap,
                    "settings" to mapOf(
                        "readReceipts" to true,
                        "typingIndicator" to true,
                        "showOnline" to true,
                        "allowUnknown" to true,
                        "notificationMode" to "PRIVATE",
                    )
                )
                val updates = hashMapOf<String, Any?>(
                    "publicProfiles/${user.uid}" to publicProfile,
                    "users/${user.uid}" to privateProfile,
                )
                database.reference.updateChildren(updates).await()
                syncMessagingToken()
                startPresence()
                return database.reference.child("publicProfiles").child(user.uid).get().await().toUserProfile()
                    ?: UserProfile(uid = user.uid, publicId = displayId, username = "Anonymous $suffix")
            }
        }
        error("Could not allocate a unique public ID")
    }

    override suspend fun syncMessagingToken() {
        val uid = currentUid ?: return
        val token = runCatching { messaging.token.await() }.getOrNull() ?: return
        database.reference.child("fcmTokens").child(uid).child(token).setValue(true).await()
    }

    override fun startPresence() {
        val uid = currentUid ?: return
        if (presenceListener != null) return
        val connectedRef = database.getReference(".info/connected")
        val onlineRef = database.reference.child("publicProfiles").child(uid).child("online")
        presenceListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.getValue(Boolean::class.java) == true) {
                    onlineRef.onDisconnect().setValue(false)
                    onlineRef.setValue(true)
                }
            }
            override fun onCancelled(error: DatabaseError) = Unit
        }.also { connectedRef.addValueEventListener(it) }
    }

    private fun randomPublicIdKey(): String = buildString(8) {
        repeat(8) { append(alphabet[random.nextInt(alphabet.length)]) }
    }

    private suspend fun claimPublicId(key: String, uid: String): Boolean = suspendCancellableCoroutine { cont ->
        val ref = database.reference.child("publicIds").child(key)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val current = currentData.getValue(String::class.java)
                return when {
                    current == null -> {
                        currentData.value = uid
                        Transaction.success(currentData)
                    }
                    current == uid -> Transaction.success(currentData)
                    else -> Transaction.abort()
                }
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
                if (cont.isActive) cont.resume(error == null && committed)
            }
        })
    }
}
