package com.FrosvanDevelop.Frsgram.data.repository

import com.FrosvanDevelop.Frsgram.domain.model.UserProfile

interface UserRepository {
    suspend fun getProfile(uid: String): UserProfile?
    suspend fun findByPublicId(publicId: String): UserProfile?
    suspend fun updateMyProfile(username: String, bio: String, avatarUrl: String = "")
    suspend fun blockUser(uid: String)
    suspend fun unblockUser(uid: String)
    suspend fun reportUser(uid: String, reason: String, messageIds: List<String> = emptyList())
}
