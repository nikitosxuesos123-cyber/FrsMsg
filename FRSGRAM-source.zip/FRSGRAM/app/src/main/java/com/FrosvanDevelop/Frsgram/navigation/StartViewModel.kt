package com.FrosvanDevelop.Frsgram.navigation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface StartState {
    data object Loading : StartState
    data object NeedsOnboarding : StartState
    data object Ready : StartState
    data class Error(val message: String) : StartState
}

@HiltViewModel
class StartViewModel @Inject constructor(
    private val authRepository: AuthRepository,
) : ViewModel() {
    private val _state = MutableStateFlow<StartState>(StartState.Loading)
    val state: StateFlow<StartState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { authRepository.getCurrentProfile() }
                .onSuccess { profile ->
                    if (profile == null) {
                        _state.value = StartState.NeedsOnboarding
                    } else {
                        authRepository.startPresence()
                        runCatching { authRepository.syncMessagingToken() }
                        _state.value = StartState.Ready
                    }
                }
                .onFailure { _state.value = StartState.Error(it.message ?: "Startup failed") }
        }
    }
}
