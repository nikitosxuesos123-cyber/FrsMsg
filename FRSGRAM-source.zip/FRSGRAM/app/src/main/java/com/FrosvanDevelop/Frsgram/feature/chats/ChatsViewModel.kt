package com.FrosvanDevelop.Frsgram.feature.chats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.ChatRepository
import com.FrosvanDevelop.Frsgram.domain.model.ChatSummary
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

data class ChatsUiState(
    val loading: Boolean = true,
    val chats: List<ChatSummary> = emptyList(),
    val error: String = "",
)

@HiltViewModel
class ChatsViewModel @Inject constructor(
    chatRepository: ChatRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(ChatsUiState())
    val state: StateFlow<ChatsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            chatRepository.observeChats()
                .catch { _state.value = _state.value.copy(loading = false, error = it.message ?: "Couldn't load chats") }
                .collect { chats -> _state.value = ChatsUiState(loading = false, chats = chats) }
        }
    }
}
