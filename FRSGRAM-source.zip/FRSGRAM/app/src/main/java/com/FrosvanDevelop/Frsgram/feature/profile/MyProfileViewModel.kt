package com.FrosvanDevelop.Frsgram.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.AuthRepository
import com.FrosvanDevelop.Frsgram.data.repository.UserRepository
import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MyProfileUiState(
    val profile: UserProfile? = null,
    val username: String = "",
    val bio: String = "",
    val editing: Boolean = false,
    val saving: Boolean = false,
    val error: String = "",
)

@HiltViewModel
class MyProfileViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val users: UserRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(MyProfileUiState())
    val state: StateFlow<MyProfileUiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            runCatching { auth.getCurrentProfile() }
                .onSuccess { p -> _state.value = MyProfileUiState(profile = p, username = p?.username.orEmpty(), bio = p?.bio.orEmpty()) }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Couldn't load profile") }
        }
    }

    fun edit() { _state.value = _state.value.copy(editing = true) }
    fun cancel() { val p = state.value.profile; _state.value = _state.value.copy(editing = false, username = p?.username.orEmpty(), bio = p?.bio.orEmpty()) }
    fun setUsername(value: String) { _state.value = _state.value.copy(username = value.take(32)) }
    fun setBio(value: String) { _state.value = _state.value.copy(bio = value.take(140)) }

    fun save() {
        viewModelScope.launch {
            _state.value = _state.value.copy(saving = true, error = "")
            runCatching { users.updateMyProfile(state.value.username, state.value.bio, state.value.profile?.avatarUrl.orEmpty()) }
                .onSuccess { refresh() }
                .onFailure { _state.value = _state.value.copy(saving = false, error = it.message ?: "Couldn't save profile") }
        }
    }
}
