package com.FrosvanDevelop.Frsgram.navigation

object Routes {
    const val Splash = "splash"
    const val Onboarding = "onboarding"
    const val ProfileSetup = "profileSetup"
    const val Chats = "chats"
    const val Search = "search"
    const val MyProfile = "myProfile"
    const val Settings = "settings"
    const val Chat = "chat/{chatId}"

    fun chat(chatId: String) = "chat/$chatId"
}
