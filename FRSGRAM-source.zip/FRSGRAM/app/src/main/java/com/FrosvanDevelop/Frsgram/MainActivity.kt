package com.FrosvanDevelop.Frsgram

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.FrosvanDevelop.Frsgram.core.design.FrsTheme
import com.FrosvanDevelop.Frsgram.core.util.SecurityPrefs.applyScreenshotPolicy
import com.FrosvanDevelop.Frsgram.navigation.FrsgramRoot
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        applyScreenshotPolicy()
        requestNotificationsIfNeeded()
        setContent {
            FrsTheme { FrsgramRoot() }
        }
    }

    override fun onResume() {
        super.onResume()
        applyScreenshotPolicy()
    }

    private fun requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
