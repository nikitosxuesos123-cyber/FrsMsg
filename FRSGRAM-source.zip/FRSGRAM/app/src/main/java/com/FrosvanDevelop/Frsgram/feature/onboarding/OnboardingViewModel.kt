package com.FrosvanDevelop.Frsgram.feature.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class OnboardingUiState(
    val loading: Boolean = false,
    val publicId: String = "",
    val error: String = "",
)

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val authRepository: AuthRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(OnboardingUiState())
    val state: StateFlow<OnboardingUiState> = _state.asStateFlow()

    fun createIdentity() {
        if (_state.value.loading || _state.value.publicId.isNotEmpty()) return
        viewModelScope.launch {
            _state.value = OnboardingUiState(loading = true)
            runCatching { authRepository.createAnonymousIdentity() }
                .onSuccess { _state.value = OnboardingUiState(publicId = it.publicId) }
                .onFailure { _state.value = OnboardingUiState(error = it.message ?: "Could not create identity") }
        }
    }
}
