package com.FrosvanDevelop.Frsgram.core.design

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FrsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val alpha by animateFloatAsState(if (enabled) 1f else .45f, label = "buttonAlpha")
    Box(
        modifier = modifier
            .height(52.dp)
            .alpha(alpha)
            .background(FrsColors.Accent, RoundedCornerShape(14.dp))
            .clickable(
                enabled = enabled,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = FrsColors.Background, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun FrsSecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(50.dp)
            .border(1.dp, FrsColors.Divider, RoundedCornerShape(14.dp))
            .background(FrsColors.Surface, RoundedCornerShape(14.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = FrsColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun FrsTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        textStyle = TextStyle(color = FrsColors.Text, fontSize = 15.sp),
        singleLine = singleLine,
        cursorBrush = SolidColor(FrsColors.Accent),
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(FrsColors.Input, RoundedCornerShape(14.dp))
                    .border(1.dp, FrsColors.Divider, RoundedCornerShape(14.dp))
                    .padding(horizontal = 16.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(placeholder, color = FrsColors.Muted, fontSize = 15.sp)
                    inner()
                }
            }
        },
    )
}

@Composable
fun FrsAvatar(label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(FrsColors.Elevated, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center,
    ) {
        Text(label.take(1).uppercase().ifEmpty { "A" }, color = FrsColors.Accent, fontWeight = FontWeight.SemiBold)
    }
}
