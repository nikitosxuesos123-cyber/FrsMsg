package com.FrosvanDevelop.Frsgram.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.AuthRepository
import com.FrosvanDevelop.Frsgram.data.repository.UserRepository
import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProfileSetupUiState(
    val profile: UserProfile? = null,
    val username: String = "",
    val bio: String = "",
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: String = "",
)

@HiltViewModel
class ProfileSetupViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(ProfileSetupUiState())
    val state: StateFlow<ProfileSetupUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val profile = authRepository.getCurrentProfile()
            _state.value = _state.value.copy(
                profile = profile,
                username = profile?.username.orEmpty(),
                bio = profile?.bio.orEmpty(),
            )
        }
    }

    fun setUsername(value: String) { _state.value = _state.value.copy(username = value.take(32)) }
    fun setBio(value: String) { _state.value = _state.value.copy(bio = value.take(140)) }

    fun save() {
        if (_state.value.saving) return
        viewModelScope.launch {
            _state.value = _state.value.copy(saving = true, error = "")
            runCatching { userRepository.updateMyProfile(_state.value.username, _state.value.bio) }
                .onSuccess { _state.value = _state.value.copy(saving = false, saved = true) }
                .onFailure { _state.value = _state.value.copy(saving = false, error = it.message ?: "Could not save profile") }
        }
    }
}
