package com.FrosvanDevelop.Frsgram.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseMediaRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val auth: FirebaseAuth,
    private val storage: FirebaseStorage,
) : MediaRepository {
    override suspend fun uploadChatImage(chatId: String, peerUid: String, uri: Uri): String {
        val me = auth.currentUser?.uid ?: error("Not authenticated")
        val bytes = withContext(Dispatchers.IO) { compress(uri) }
        require(bytes.size <= 8 * 1024 * 1024) { "Image is too large" }
        val pair = listOf(me, peerUid).sorted()
        val filename = "${System.currentTimeMillis()}-${bytes.contentHashCode()}.jpg"
        val ref = storage.reference.child("chatMedia/${pair[0]}/${pair[1]}/$filename")
        ref.putBytes(bytes).await()
        return ref.path
    }

    override suspend fun resolveDownloadUrl(storagePath: String): String {
        require(storagePath.startsWith("chatMedia/"))
        return storage.reference.child(storagePath).downloadUrl.await().toString()
    }

    private fun compress(uri: Uri): ByteArray {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1920) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = resolver.openInputStream(uri).use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: error("Unable to decode image")
        return ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            bitmap.recycle()
            out.toByteArray()
        }
    }
}
