package com.FrosvanDevelop.Frsgram.feature.onboarding

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.FrosvanDevelop.Frsgram.core.design.*

@Composable
fun OnboardingScreen(
    onContinueToProfile: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    Box(
        Modifier
            .fillMaxSize()
            .background(FrsColors.Background)
            .padding(horizontal = 28.dp, vertical = 30.dp),
    ) {
        AnimatedContent(targetState = state.publicId.isNotEmpty(), label = "onboarding") { hasId ->
            if (!hasId) {
                IntroContent(
                    loading = state.loading,
                    error = state.error,
                    onContinue = viewModel::createIdentity,
                )
            } else {
                IdentityContent(
                    publicId = state.publicId,
                    onCopy = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("FRSGRAM ID", state.publicId))
                    },
                    onContinue = onContinueToProfile,
                )
            }
        }
    }
}

@Composable
private fun IntroContent(loading: Boolean, error: String, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        Spacer(Modifier.height(18.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(
                Modifier.size(72.dp).background(FrsColors.Text, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text("F", color = FrsColors.Background, fontWeight = FontWeight.Bold, fontSize = 30.sp)
            }
            Spacer(Modifier.height(30.dp))
            Text("FRSGRAM", color = FrsColors.Text, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
            Spacer(Modifier.height(12.dp))
            Text("Anonymous conversations.", color = FrsColors.TextSecondary, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "No phone number. No email. Just you.",
                color = FrsColors.Muted,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
            )
            if (loading) {
                Spacer(Modifier.height(34.dp))
                LoadingMark()
                Spacer(Modifier.height(14.dp))
                Text("Creating anonymous identity", color = FrsColors.TextSecondary, fontSize = 13.sp)
            }
            if (error.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text(error, color = MaterialError, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        }
        FrsButton(
            text = if (loading) "Creating identity…" else "Continue",
            enabled = !loading,
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

private val MaterialError = Color(0xFFC9A1A1)

@Composable
private fun LoadingMark() {
    val transition = rememberInfiniteTransition(label = "loader")
    val scale by transition.animateFloat(
        initialValue = .82f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "loaderScale",
    )
    val alpha by transition.animateFloat(
        initialValue = .35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "loaderAlpha",
    )
    Box(
        Modifier.size(34.dp).scale(scale).alpha(alpha)
            .background(FrsColors.Accent, RoundedCornerShape(12.dp)),
    )
}

@Composable
private fun IdentityContent(publicId: String, onCopy: () -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        Spacer(Modifier.height(10.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text("Your ID", color = FrsColors.TextSecondary, fontSize = 15.sp)
            Spacer(Modifier.height(22.dp))
            Box(
                Modifier.fillMaxWidth().background(FrsColors.Surface, RoundedCornerShape(18.dp))
                    .padding(horizontal = 22.dp, vertical = 26.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(publicId, color = FrsColors.Text, fontSize = 27.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "Share this ID with people you trust.",
                color = FrsColors.Muted,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(28.dp))
            FrsSecondaryButton(
                text = "Copy ID",
                onClick = onCopy,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        FrsButton("Continue", onClick = onContinue, modifier = Modifier.fillMaxWidth())
    }
}
