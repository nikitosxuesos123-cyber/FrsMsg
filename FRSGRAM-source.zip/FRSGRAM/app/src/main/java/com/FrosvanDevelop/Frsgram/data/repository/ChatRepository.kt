package com.FrosvanDevelop.Frsgram.data.repository

import com.FrosvanDevelop.Frsgram.domain.model.ChatSummary
import com.FrosvanDevelop.Frsgram.domain.model.Message
import kotlinx.coroutines.flow.Flow

interface ChatRepository {
    fun observeChats(): Flow<List<ChatSummary>>
    suspend fun openOrCreateChat(peerUid: String): String
    suspend fun getPeerUid(chatId: String): String
    fun observeMessages(chatId: String): Flow<List<Message>>
    suspend fun loadOlder(chatId: String, beforeTimestamp: Long, limit: Int = 50): List<Message>
    suspend fun sendText(chatId: String, text: String, replyTo: String = "")
    suspend fun sendImage(chatId: String, mediaUrl: String, replyTo: String = "")
    suspend fun editMessage(chatId: String, messageId: String, newText: String)
    suspend fun deleteMessage(chatId: String, messageId: String)
    suspend fun markRead(chatId: String)
    suspend fun muteChat(chatId: String, muted: Boolean)
    suspend fun archiveChat(chatId: String, archived: Boolean)
}
