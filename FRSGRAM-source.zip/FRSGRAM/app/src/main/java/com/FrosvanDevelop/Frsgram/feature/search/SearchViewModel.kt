package com.FrosvanDevelop.Frsgram.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.FrosvanDevelop.Frsgram.data.repository.AuthRepository
import com.FrosvanDevelop.Frsgram.data.repository.ChatRepository
import com.FrosvanDevelop.Frsgram.data.repository.UserRepository
import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val loading: Boolean = false,
    val result: UserProfile? = null,
    val error: String = "",
    val openChatId: String = "",
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val users: UserRepository,
    private val chats: ChatRepository,
    private val auth: AuthRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    fun setQuery(value: String) {
        _state.value = _state.value.copy(query = value.take(12), error = "", result = null)
    }

    fun search() {
        val query = state.value.query
        if (query.isBlank()) return
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = "", result = null)
            runCatching { users.findByPublicId(query) }
                .onSuccess { profile ->
                    _state.value = _state.value.copy(
                        loading = false,
                        result = profile?.takeUnless { it.uid == auth.currentUid },
                        error = if (profile == null || profile.uid == auth.currentUid) "User not found" else "",
                    )
                }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message ?: "Search failed") }
        }
    }

    fun message() {
        val profile = state.value.result ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = "")
            runCatching { chats.openOrCreateChat(profile.uid) }
                .onSuccess { _state.value = _state.value.copy(loading = false, openChatId = it) }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message ?: "Couldn't open chat") }
        }
    }
}
