package com.FrosvanDevelop.Frsgram.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ChatEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class FrsgramDatabase : RoomDatabase() {
    abstract fun dao(): FrsgramDao
}
