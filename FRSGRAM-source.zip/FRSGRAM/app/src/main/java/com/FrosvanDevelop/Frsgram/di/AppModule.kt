package com.FrosvanDevelop.Frsgram.di

import android.content.Context
import androidx.room.Room
import com.FrosvanDevelop.Frsgram.data.local.FrsgramDatabase
import com.FrosvanDevelop.Frsgram.data.repository.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseException
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object FirebaseModule {
    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseDatabase(): FirebaseDatabase = FirebaseDatabase.getInstance().also { db ->
        try {
            db.setPersistenceEnabled(true)
        } catch (_: DatabaseException) {
            // Persistence was already configured by an earlier Firebase access in this process.
        }
    }

    @Provides
    @Singleton
    fun provideFirebaseStorage(): FirebaseStorage = FirebaseStorage.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseMessaging(): FirebaseMessaging = FirebaseMessaging.getInstance()

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): FrsgramDatabase =
        Room.databaseBuilder(context, FrsgramDatabase::class.java, "frsgram-cache.db")
            .build()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: FirebaseAuthRepository): AuthRepository

    @Binds
    @Singleton
    abstract fun bindUserRepository(impl: FirebaseUserRepository): UserRepository

    @Binds
    @Singleton
    abstract fun bindChatRepository(impl: FirebaseChatRepository): ChatRepository

    @Binds
    @Singleton
    abstract fun bindMediaRepository(impl: FirebaseMediaRepository): MediaRepository
}
