package com.FrosvanDevelop.Frsgram.feature.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.FrosvanDevelop.Frsgram.core.design.*
import com.FrosvanDevelop.Frsgram.domain.model.Message
import com.FrosvanDevelop.Frsgram.domain.model.MessageStatus
import com.FrosvanDevelop.Frsgram.domain.model.MessageType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    onBack: () -> Unit,
    viewModel: ChatViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val context = LocalContext.current
    var selected by remember { mutableStateOf<Message?>(null) }
    var editText by remember { mutableStateOf("") }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let(viewModel::sendImage) }

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    Box(Modifier.fillMaxSize().background(FrsColors.Background)) {
        Column(Modifier.fillMaxSize()) {
            ChatHeader(
                username = state.peer?.username ?: "Conversation",
                subtitle = state.peer?.let { if (it.online) "Online" else it.publicId }.orEmpty(),
                onBack = onBack,
                onMore = { selected = Message(messageId = "__menu__") },
            )
            Box(Modifier.fillMaxWidth().height(1.dp).background(FrsColors.Divider))

            if (state.loading) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Loading conversation…", color = FrsColors.Muted, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    items(state.messages, key = { it.messageId }) { message ->
                        MessageBubble(
                            message = message,
                            mine = message.senderId == state.myUid,
                            imageUrl = state.imageUrls[message.messageId].orEmpty(),
                            onLongClick = {
                                selected = message
                                editText = message.text
                            },
                        )
                    }
                }
            }

            state.replyTo?.let { reply ->
                Row(Modifier.fillMaxWidth().background(FrsColors.SecondaryBackground).padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(2.dp).height(32.dp).background(FrsColors.Accent))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Replying", color = FrsColors.TextSecondary, fontSize = 11.sp)
                        Text(reply.text.ifBlank { "Photo" }, color = FrsColors.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Icon(Icons.Rounded.Close, null, tint = FrsColors.Muted, modifier = Modifier.size(20.dp).clickableNoRipple { viewModel.setReply(null) })
                }
            }
            MessageComposer(
                value = state.input,
                onValueChange = viewModel::setInput,
                onSend = viewModel::send,
                onAdd = { imagePicker.launch("image/*") },
                loading = state.sendingMedia,
            )
        }

        if (state.error.isNotBlank()) {
            Text(
                state.error,
                color = FrsColors.Text,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 82.dp).background(FrsColors.Elevated, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 9.dp).clickableNoRipple(viewModel::clearError),
            )
        }

        selected?.let { message ->
            if (message.messageId == "__menu__") {
                ConversationMenu(
                    onDismiss = { selected = null },
                    onReport = { viewModel.reportPeer("Other"); selected = null },
                    onBlock = { viewModel.blockPeer(onBack); selected = null },
                )
            } else {
                MessageMenu(
                    message = message,
                    mine = message.senderId == state.myUid,
                    editText = editText,
                    onEditText = { editText = it },
                    onDismiss = { selected = null },
                    onReply = { viewModel.setReply(message); selected = null },
                    onCopy = {
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("message", message.text))
                        selected = null
                    },
                    onEdit = { viewModel.edit(message, editText); selected = null },
                    onDelete = { viewModel.delete(message); selected = null },
                )
            }
        }
    }
}

@Composable
private fun ChatHeader(username: String, subtitle: String, onBack: () -> Unit, onMore: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        HeaderTap(Icons.Rounded.ArrowBack, onBack)
        FrsAvatar(username, Modifier.size(38.dp))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(username, color = FrsColors.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = FrsColors.Muted, fontSize = 11.sp)
        }
        HeaderTap(Icons.Rounded.MoreVert, onMore)
    }
}

@Composable
private fun HeaderTap(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickableNoRipple(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = FrsColors.TextSecondary, modifier = Modifier.size(22.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(message: Message, mine: Boolean, imageUrl: String, onLongClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 310.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(if (mine) FrsColors.Elevated else FrsColors.Surface)
                .combinedClickable(onClick = {}, onLongClick = onLongClick)
                .padding(if (message.type == MessageType.IMAGE.name && !message.deleted) 5.dp else 11.dp)
        ) {
            when {
                message.deleted -> Text("Message deleted", color = FrsColors.Muted, fontSize = 13.sp, fontStyle = FontStyle.Italic)
                message.type == MessageType.IMAGE.name -> {
                    AsyncImage(
                        model = imageUrl.ifBlank { null },
                        contentDescription = "Shared image",
                        modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 300.dp).clip(RoundedCornerShape(13.dp)),
                        contentScale = ContentScale.Crop,
                    )
                    Spacer(Modifier.height(5.dp))
                    MessageMeta(message, mine)
                }
                else -> {
                    Text(message.text, color = FrsColors.Text, fontSize = 14.sp, lineHeight = 19.sp)
                    Spacer(Modifier.height(5.dp))
                    MessageMeta(message, mine)
                }
            }
        }
    }
}

@Composable
private fun MessageMeta(message: Message, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
        if (message.editedAt > 0) {
            Text("edited  ", color = FrsColors.Muted, fontSize = 9.sp)
        }
        Text(formatTime(message.timestamp), color = FrsColors.Muted, fontSize = 9.sp)
        if (mine) {
            Spacer(Modifier.width(4.dp))
            Text(
                when (message.status) {
                    MessageStatus.SENDING -> "·"
                    MessageStatus.SENT -> "✓"
                    MessageStatus.DELIVERED -> "✓✓"
                    MessageStatus.READ -> "✓✓"
                    MessageStatus.FAILED -> "!"
                },
                color = if (message.status == MessageStatus.READ) FrsColors.Accent else FrsColors.Muted,
                fontSize = 10.sp,
            )
        }
    }
}

@Composable
private fun MessageComposer(value: String, onValueChange: (String) -> Unit, onSend: () -> Unit, onAdd: () -> Unit, loading: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(FrsColors.SecondaryBackground).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).clickableNoRipple(onAdd), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Add, null, tint = FrsColors.TextSecondary, modifier = Modifier.size(23.dp))
        }
        FrsTextField(value, onValueChange, if (loading) "Uploading image…" else "Message…", Modifier.weight(1f), singleLine = false)
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(if (value.isBlank()) FrsColors.Surface else FrsColors.Accent).clickableNoRipple { if (value.isNotBlank()) onSend() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.ArrowUpward, null, tint = if (value.isBlank()) FrsColors.Muted else FrsColors.Background, modifier = Modifier.size(21.dp))
        }
    }
}

@Composable
private fun MessageMenu(
    message: Message,
    mine: Boolean,
    editText: String,
    onEditText: (String) -> Unit,
    onDismiss: () -> Unit,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = .55f)).clickableNoRipple(onDismiss)) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(FrsColors.Elevated, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).padding(18.dp)
                .clickableNoRipple {},
        ) {
            if (mine && message.type == MessageType.TEXT.name && !message.deleted) {
                FrsTextField(editText, onEditText, "Edit message", Modifier.fillMaxWidth(), singleLine = false)
                Spacer(Modifier.height(10.dp))
                FrsSecondaryButton("Save edit", onEdit, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }
            FrsSecondaryButton("Reply", onReply, Modifier.fillMaxWidth())
            if (message.text.isNotBlank() && !message.deleted) {
                Spacer(Modifier.height(8.dp)); FrsSecondaryButton("Copy", onCopy, Modifier.fillMaxWidth())
            }
            if (mine && !message.deleted) {
                Spacer(Modifier.height(8.dp)); FrsSecondaryButton("Delete message", onDelete, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun ConversationMenu(onDismiss: () -> Unit, onReport: () -> Unit, onBlock: () -> Unit) {
    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = .55f)).clickableNoRipple(onDismiss)) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(FrsColors.Elevated, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).padding(18.dp).clickableNoRipple {},
        ) {
            FrsSecondaryButton("Report", onReport, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            FrsSecondaryButton("Block user", onBlock, Modifier.fillMaxWidth())
        }
    }
}

private fun formatTime(value: Long): String = if (value <= 0) "…" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(value))

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = androidx.compose.foundation.clickable(
    interactionSource = MutableInteractionSource(), indication = null, onClick = onClick,
)
