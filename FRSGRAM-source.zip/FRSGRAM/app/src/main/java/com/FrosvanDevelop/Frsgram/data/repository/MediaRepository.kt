package com.FrosvanDevelop.Frsgram.data.repository

import android.net.Uri

interface MediaRepository {
    suspend fun uploadChatImage(chatId: String, peerUid: String, uri: Uri): String
    suspend fun resolveDownloadUrl(storagePath: String): String
}
