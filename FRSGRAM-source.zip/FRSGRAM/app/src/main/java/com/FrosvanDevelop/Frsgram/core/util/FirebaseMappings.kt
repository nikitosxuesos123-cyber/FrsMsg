package com.FrosvanDevelop.Frsgram.core.util

import com.FrosvanDevelop.Frsgram.domain.model.UserProfile
import com.google.firebase.database.DataSnapshot

fun DataSnapshot.toUserProfile(): UserProfile? {
    if (!exists()) return null
    return UserProfile(
        uid = key.orEmpty(),
        publicId = child("publicId").getValue(String::class.java).orEmpty(),
        username = child("username").getValue(String::class.java).orEmpty(),
        bio = child("bio").getValue(String::class.java).orEmpty(),
        avatarUrl = child("avatarUrl").getValue(String::class.java).orEmpty(),
        createdAt = child("createdAt").getValue(Long::class.java) ?: 0L,
        online = child("online").getValue(Boolean::class.java) ?: false,
    )
}
