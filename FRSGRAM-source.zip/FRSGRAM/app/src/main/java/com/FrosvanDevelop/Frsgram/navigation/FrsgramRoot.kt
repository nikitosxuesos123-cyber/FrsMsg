package com.FrosvanDevelop.Frsgram.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.FrosvanDevelop.Frsgram.core.design.FrsColors
import com.FrosvanDevelop.Frsgram.feature.chat.ChatScreen
import com.FrosvanDevelop.Frsgram.feature.chats.ChatsScreen
import com.FrosvanDevelop.Frsgram.feature.onboarding.OnboardingScreen
import com.FrosvanDevelop.Frsgram.feature.profile.MyProfileScreen
import com.FrosvanDevelop.Frsgram.feature.profile.ProfileSetupScreen
import com.FrosvanDevelop.Frsgram.feature.search.SearchScreen
import com.FrosvanDevelop.Frsgram.feature.settings.SettingsScreen

@Composable
fun FrsgramRoot() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.Splash,
        enterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(180)) },
        exitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(180)) },
        popEnterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(180)) },
        popExitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(180)) },
    ) {
        composable(Routes.Splash) {
            SplashRoute(
                onNeedsOnboarding = {
                    nav.navigate(Routes.Onboarding) { popUpTo(Routes.Splash) { inclusive = true } }
                },
                onReady = {
                    nav.navigate(Routes.Chats) { popUpTo(Routes.Splash) { inclusive = true } }
                },
            )
        }
        composable(Routes.Onboarding) {
            OnboardingScreen(
                onDone = { nav.navigate(Routes.ProfileSetup) { popUpTo(Routes.Onboarding) { inclusive = true } } },
            )
        }
        composable(Routes.ProfileSetup) {
            ProfileSetupScreen(
                onDone = { nav.navigate(Routes.Chats) { popUpTo(Routes.ProfileSetup) { inclusive = true } } },
            )
        }
        composable(Routes.Chats) {
            ChatsScreen(
                onOpenChat = { nav.navigate(Routes.chat(it)) },
                onSearch = { nav.navigate(Routes.Search) },
                onProfile = { nav.navigate(Routes.MyProfile) },
                onSettings = { nav.navigate(Routes.Settings) },
            )
        }
        composable(Routes.Search) {
            SearchScreen(
                onBack = { nav.popBackStack() },
                onOpenChat = { chatId ->
                    nav.navigate(Routes.chat(chatId)) {
                        popUpTo(Routes.Search) { inclusive = true }
                    }
                },
            )
        }
        composable(Routes.MyProfile) { MyProfileScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.Settings) { SettingsScreen(onBack = { nav.popBackStack() }) }
        composable(
            route = Routes.Chat,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType }),
        ) { ChatScreen(onBack = { nav.popBackStack() }) }
    }
}

@Composable
private fun SplashRoute(
    onNeedsOnboarding: () -> Unit,
    onReady: () -> Unit,
    viewModel: StartViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(state) {
        when (state) {
            StartState.NeedsOnboarding -> onNeedsOnboarding()
            StartState.Ready -> onReady()
            else -> Unit
        }
    }
    Box(Modifier.fillMaxSize().background(FrsColors.Background), contentAlignment = Alignment.Center) {
        when (val s = state) {
            is StartState.Error -> Text(s.message, color = FrsColors.TextSecondary, fontSize = 13.sp)
            else -> Text("F", color = FrsColors.Text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
