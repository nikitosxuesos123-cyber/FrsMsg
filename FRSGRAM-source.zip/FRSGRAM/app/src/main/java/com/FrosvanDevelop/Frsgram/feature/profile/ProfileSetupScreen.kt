package com.FrosvanDevelop.Frsgram.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.FrosvanDevelop.Frsgram.core.design.*

@Composable
fun ProfileSetupScreen(
    onDone: () -> Unit,
    viewModel: ProfileSetupViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(state.saved) { if (state.saved) onDone() }

    Column(
        Modifier.fillMaxSize().background(FrsColors.Background).padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Column {
            Spacer(Modifier.height(18.dp))
            Text("Set up profile", color = FrsColors.Text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(state.profile?.publicId.orEmpty(), color = FrsColors.Muted, fontSize = 14.sp)
            Spacer(Modifier.height(32.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FrsAvatar(state.username, Modifier.size(62.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Anonymous avatar", color = FrsColors.TextSecondary, fontSize = 14.sp)
                    Text("Photo can be added later", color = FrsColors.Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("Nickname", color = FrsColors.TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            FrsTextField(state.username, viewModel::setUsername, "Nickname", Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Text("Bio", color = FrsColors.TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            FrsTextField(state.bio, viewModel::setBio, "Optional bio", Modifier.fillMaxWidth(), singleLine = false)
            if (state.error.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text(state.error, color = androidx.compose.ui.graphics.Color(0xFFC9A1A1), fontSize = 13.sp)
            }
        }
        FrsButton(
            text = if (state.saving) "Saving…" else "Enter FRSGRAM",
            enabled = !state.saving,
            onClick = viewModel::save,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
