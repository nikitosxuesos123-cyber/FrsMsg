import { initializeApp } from "firebase-admin/app";
import { getDatabase } from "firebase-admin/database";
import { getMessaging } from "firebase-admin/messaging";
import { onValueCreated } from "firebase-functions/v2/database";
import { logger } from "firebase-functions";

initializeApp();

export const notifyNewMessage = onValueCreated(
  {
    ref: "/messages/{chatId}/{messageId}",
    instance: "telegrambyfrosvan-default-rtdb",
    region: "europe-west1",
  },
  async (event) => {
    const message = event.data.val() as { senderId?: string } | null;
    const senderId = message?.senderId;
    const chatId = event.params.chatId;
    if (!senderId || !chatId) return;

    const db = getDatabase();
    const chatSnap = await db.ref(`chats/${chatId}`).get();
    if (!chatSnap.exists()) return;

    const participants = Object.keys((chatSnap.child("participants").val() ?? {}) as Record<string, boolean>);
    const recipientUid = participants.find((uid) => uid !== senderId);
    if (!recipientUid) return;

    const blockedByRecipient = await db.ref(`blockedUsers/${recipientUid}/${senderId}`).get();
    if (blockedByRecipient.exists()) return;

    const muted = (await db.ref(`userChats/${recipientUid}/${chatId}/muted`).get()).val() === true;
    if (muted) return;

    const tokensSnap = await db.ref(`fcmTokens/${recipientUid}`).get();
    const tokens = Object.keys((tokensSnap.val() ?? {}) as Record<string, boolean>);
    if (tokens.length === 0) return;

    const response = await getMessaging().sendEachForMulticast({
      tokens,
      notification: {
        title: "FRSGRAM",
        body: "New message",
      },
      data: {
        chatId,
      },
      android: {
        priority: "high",
        notification: {
          channelId: "messages",
          visibility: "private",
        },
      },
    });

    const invalid: string[] = [];
    response.responses.forEach((result, index) => {
      const code = result.error?.code;
      if (code === "messaging/registration-token-not-registered" || code === "messaging/invalid-registration-token") {
        invalid.push(tokens[index]);
      }
    });
    await Promise.all(invalid.map((token) => db.ref(`fcmTokens/${recipientUid}/${token}`).remove()));
    logger.info("Private notification processed", { chatId, success: response.successCount, failed: response.failureCount });
  },
);
